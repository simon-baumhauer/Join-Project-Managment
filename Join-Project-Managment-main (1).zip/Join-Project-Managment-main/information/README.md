# Join-Project-Managment
Teamwork at Developer Akademie
